<?php
/**
 * TravelPAQ Connect Api 
 *
 * @package  TravelPAQ
 * 
 * @author   Facundo J Gonzalez <facujgg@gmail.com>
 * 
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
namespace TravelPAQ\PackagesAPI\Core;

use TravelPAQ\PackagesAPI\Exceptions\ValidationException;
/**
 * Class Total_Price
 *
 * @package TravelPAQ
 */
class Total_Price
{
	public $neto;
	public $tax;
	public $vat;
    /**
     * Constructor
     * @param Array data datos detallados de los impuesto del precio
     */
    public function __construct($data)
    {
    	if(!array_key_exists('neto', $data))
    		$data['neto'] = "";
    	$this->neto = $data['neto'];
 
 		if(!array_key_exists('tax', $data))
    		$data['tax'] = "";
    	$this->tax = $data['tax'];

 		if(!array_key_exists('vat', $data))
    		$data['vat'] = "";
    	$this->vat = $data['vat'];
 
    	
    }

}